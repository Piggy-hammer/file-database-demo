package util;

public class SuccessResponse extends Response {

    public SuccessResponse() {
        super(0, "");
    }
}
